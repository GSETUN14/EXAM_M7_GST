// Funció per afegir una nova tasca
function addTask() {
    var taskInput = document.getElementById("new-task");
    var taskText = taskInput.value.trim();

    if (taskText !== "") {
        var newTask = document.createElement("div");
        newTask.classList.add("task-item");
        newTask.innerHTML = taskText + '<button onclick="markAsCompleted(this)">Marcar com a feta</button>';

        // Afegir tasca a PENDENTS
        document.getElementById("pending-tasks").appendChild(newTask);
        taskInput.value = ""; // Esborrar el camp d'entrada
    }
}

// Funció per marcar una tasca com a feta
function markAsCompleted(button) {
    var taskItem = button.parentElement;
    taskItem.classList.add("completed"); // Afegir classe 'completed'

    // Moure tasca a FETES
    document.getElementById("completed-tasks").appendChild(taskItem);
    button.remove(); // Eliminar botó
}
